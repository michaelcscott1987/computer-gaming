/*
Michael Scott
Mr. Jones
starfish.h

*/
#ifndef starfish_H
#define starfish_h

class starfish
{
private:
	float x, y;
	int width;
	int height;
	ALLEGRO_BITMAP *starfishImage;
	float collWidth;
	float collHeight;
	float collXOffset;
	float collYOffset;
	int dir;


public:
	starfish(int, int);
	~starfish();


	float getX() { return x; }
	float getY() { return y; }
	int getWidth() { return width; }
	int getHeight() { return height; }
	void drawPlayer(int, int);
	float getCollWidth() { return collWidth; }
	float getCollHeight() { return collHeight; }
	float getCollXOff() { return collXOffset; }
	float getCollYOff() { return collYOffset; }
};


starfish::starfish(int xnumber, int ynumber)
{
	starfishImage = al_load_bitmap("starfish.bmp");
	al_convert_mask_to_alpha(starfishImage, al_map_rgb(255, 0, 255));
	width = al_get_bitmap_width(starfishImage);
	height = al_get_bitmap_height(starfishImage);
	x = xnumber;
	y = ynumber;

	int dir = 1;


	collWidth = width * .8;
	collHeight = height * .8;
	collXOffset = (width - collWidth) / 2.0;
	collYOffset = (height - collHeight) / 2.0;
}


starfish::~starfish()
{
	al_destroy_bitmap(starfishImage);
}

void starfish::drawPlayer(int mapx, int mapy)
{
	al_draw_bitmap(starfishImage, x - mapx, y - mapy, 0);
}


#endif
