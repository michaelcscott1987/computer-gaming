/*
Michael Scott
Mr. Jones
fish.h

*/
#ifndef fish_H
#define fish_h
 
class fish
{
private:
	float x, y;
	int width;
	int height;
	ALLEGRO_BITMAP *fishImage;
	float collWidth;
	float collHeight;
	float collXOffset;
	float collYOffset;
	int dir;


public:
	fish(int, int);
	~fish();


	float getX() { return x; }
	float getY() { return y; }
	int getWidth() { return width; }
	int getHeight() { return height; }
	void drawPlayer(int, int);
	float getCollWidth() { return collWidth; }
	float getCollHeight() { return collHeight; }
	float getCollXOff() { return collXOffset; }
	float getCollYOff() { return collYOffset; }
};


fish::fish(int xnumber, int ynumber)
{
	fishImage = al_load_bitmap("fish.bmp");
	al_convert_mask_to_alpha(fishImage, al_map_rgb(255, 0, 255));
	width = al_get_bitmap_width(fishImage);
	height = al_get_bitmap_height(fishImage);
	x = xnumber;
	y = ynumber;

	int dir = 1;


	collWidth = width * .8;
	collHeight = height * .8;
	collXOffset = (width - collWidth) / 2.0;
	collYOffset = (height - collHeight) / 2.0;
}


fish::~fish()
{
	al_destroy_bitmap(fishImage);
}

void fish::drawPlayer(int mapx, int mapy)
{
	al_draw_bitmap(fishImage, x - mapx, y - mapy, 0);
}

 
#endif
