/*
Michael Scott
Mr. Jones
Diver.h

*/

#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <stdio.h>
#include <allegro5\allegro_audio.h>
#include <allegro5\allegro_acodec.h>
#include "mappy_A5.h"

int collided(int, int);
#include "sharkhandler.h"
#include "sharkclass.h"
#include "Diver.h"
#include "fish.h"
#include "starfish.h"
void altdis(int &, int);
bool spriteCollide(Shark *, Diver *);
bool spriteCollides(Shark *, fish*);
bool spriteCollides1(Shark *, starfish*);
int main()
{
	ALLEGRO_DISPLAY *display = NULL;
	ALLEGRO_EVENT_QUEUE *eventQueue = NULL;
	ALLEGRO_TIMER *timer = NULL;
	 
	bool redrawRequired = true, quit = false; int mapxoff, mapyoff;
 
	if (!al_init())
	{
		return -1;
	}

 
	if (!al_install_keyboard())
	{
		return -1;
	}

	 
	timer = al_create_timer(1.0 / FPS);
	if (!timer)
	{
		return -3;
	}

	 
	display = al_create_display(W, H);
	if (!display)
	{
		al_destroy_timer(timer);
		return -7;
	}
	
	al_init_font_addon();
	al_init_image_addon();

 
	
	al_init_ttf_addon();
	text = al_load_font("arial.ttf", 38, 0);
	 

	 
	 
	al_set_target_bitmap(al_get_backbuffer(display));

 
	Shark *shark = new Shark;
	starfish *Starfish = new starfish(300, 300);
	starfish *Starfish1 = new starfish(600, 400);
	fish *Fish = new fish(1000, 500);
	Diver *diver = new Diver(400, 400);
	
	Diver *diver1 = new Diver(500, 500);
	 
	eventQueue = al_create_event_queue();
	if (!eventQueue)
	{
		al_destroy_timer(timer);
		al_destroy_display(display);
		return -1;
	}

	 
	al_register_event_source(eventQueue, al_get_display_event_source(display));
	al_register_event_source(eventQueue, al_get_timer_event_source(timer));
	al_register_event_source(eventQueue, al_get_keyboard_event_source());

	al_init_primitives_addon();

	 
	al_install_audio();
	al_init_acodec_addon();
	al_reserve_samples(2);

	music = al_load_sample("Creepy_Percussion_1.wav");

	if (MapLoad("newwater.FMP", 1) != 0)
	{
		return -8;
	}

	 
	altdis(type, start);

	 
	al_flip_display();

 
	al_start_timer(timer);

 
	while (!quit)
	{
		ALLEGRO_EVENT evt;
	 
		al_wait_for_event(eventQueue, &evt);

		switch (evt.type)
		{
		case ALLEGRO_EVENT_KEY_DOWN:
			switch (evt.keyboard.keycode)
			{
			case ALLEGRO_KEY_ESCAPE:
				quit = true;
				break;
			case ALLEGRO_KEY_RIGHT:
				keys[RIGHT] = true;
				break;
			case ALLEGRO_KEY_UP:
				keys[up] = true;
				break;
			case ALLEGRO_KEY_LEFT:
				keys[LEFT] = true;
				break;
			case ALLEGRO_KEY_DOWN:
				keys[down] = true;
				break;
			case ALLEGRO_KEY_SPACE:
				keys[SPACE] = true;
				break;
			case ALLEGRO_KEY_P:
				keys[P] = true;
				break;
			case ALLEGRO_KEY_Q:
				keys[Q] = true;
				break;
			case ALLEGRO_KEY_S:
				keys[S] = true;
				break;
			}
			break;

		case ALLEGRO_EVENT_KEY_UP:
			switch (evt.keyboard.keycode)
			{
			case ALLEGRO_KEY_ESCAPE:
				quit = true;
				break;
			case ALLEGRO_KEY_LEFT:
				keys[LEFT] = false;
				break;
			case ALLEGRO_KEY_RIGHT:
				keys[RIGHT] = false;
				break;
			case ALLEGRO_KEY_UP:
				keys[up] = false;
				break;
			case ALLEGRO_KEY_DOWN:
				keys[down] = false;
				break;
			case ALLEGRO_KEY_SPACE:
				keys[SPACE] = false;
				break;
			case ALLEGRO_KEY_P:
				keys[P] = false;
				break;
			case ALLEGRO_KEY_Q:
				keys[Q] = true;
				break;
			case ALLEGRO_KEY_S:
				keys[S] = false;
				break;
			}
			break;

		case ALLEGRO_EVENT_DISPLAY_CLOSE:
			quit = true;
			break;

		case ALLEGRO_EVENT_TIMER:

			if (type == start)
			{
				if (keys[S])
					altdis(type, play);
				if (keys[Q])
					quit = true;
			}

			if (type == pause)
			{
				if (keys[S])
					altdis(type, play);
				else if (keys[Q])
					quit = true;
			}

			if (type == play)
			{
				shark->updatePlayer();
				 
				 

				 
				al_play_sample(music, .5, 0, 1, ALLEGRO_PLAYMODE_LOOP, 0);


				 
				mapxoff = shark->getX() + shark->getWidth() / 2 - W / 2 + 10;
				mapyoff = shark->getY() + shark->getHeight() / 2 - H / 2 + 10;

 
				if (mapxoff < 0)
					mapxoff= 0;
				if (mapxoff>(mapwidth * mapblockwidth - W))
					mapxoff = mapwidth * mapblockwidth - W;
				if (mapyoff < 0)
					mapyoff = 0;
				if (mapyoff >(mapheight * mapblockheight - H))
					mapyoff = mapheight * mapblockheight - H;

			 
				if (spriteCollide(shark, diver))
				{
					shark->setLife(shark->getLife() - 1);

					if (shark->getLife() == 0)
					{
						shark->setX(100);
						shark->setY(300);
						shark->setLives(shark->getLives() - 1);
						if (shark->getLives() == 0)
						{
							altdis(type, Killed);
						}
						else if (shark->getLives() > 0)
						{
							shark->setLife(1);
						}
					}
 
				}
				if (spriteCollides1(shark, Starfish))
				{
				 
					shark->setPoints(shark->getPoints() + 1);
					 
					 
					 
				}
				if (spriteCollides(shark, Fish))
				{
					shark->setLife(shark->getLife() - 1);

					if (shark->getLife() == 0)
					{
						shark->setLives(shark->getLives() - 1);
						shark->setX(100);
						shark->setY(200);
						if (shark->getLives() == 0)
						{
							altdis(type, Killed);
						}
						else if (shark->getLives() > 0)
						{
							shark->setLife(1);
						}
					}

					
					 
				}

				if (keys[P])
					altdis(type, pause);

				 
				if (shark->getY() + shark->getHeight() > 600)
				{
					shark->setLives(shark->getLives() - 1);
					if (shark->getLives() == 0)
						altdis(type, Killed);
					else
					{
						shark->setLife(1);
						shark->setX(100);
						shark->setY(200);
					}

	
				}
				if (shark->getY() + shark->getHeight() < 0)
				{
					shark->setLives(shark->getLives() - 1);
					if (shark->getLives() == 0)
						altdis(type, Killed);
					else
					{
						shark->setLife(1);
						shark->setX(100);
						shark->setY(200);
					}
				}




				 
				if (shark->getX() >= 2000 )
				{
					altdis(type, Completion);
				}

				redrawRequired = true;
			}
			break;
		}  

		if (redrawRequired && al_is_event_queue_empty(eventQueue))
		{
			if (type == play)
			{
				redrawRequired = false;
				al_clear_to_color(al_map_rgb(0, 0, 0));

				 
				MapDrawBG(mapxoff, mapyoff, 0, 0, W , H );
				MapDrawFG(mapxoff, mapyoff, 0, 0, W, H,0 );

				 
				 
				al_draw_textf(text, WHITE, 700, 100, 0, "Lives: %i", shark->getLives());
				al_draw_textf(text, WHITE, 700, 60, 0, "Points: %i", shark->getPoints());
				al_draw_textf(text, WHITE, 700, 20, 0, "Life: %i", shark->getLife());
				
				shark->drawPlayer(mapxoff, mapyoff);
				
				Fish->drawPlayer(mapxoff, mapyoff);
				Starfish->drawPlayer(mapxoff, mapyoff);
				Starfish1->drawPlayer(mapxoff, mapyoff);
				diver->drawPlayer(mapxoff, mapyoff);
				diver1->drawPlayer(mapxoff, mapyoff);
			}

			else if (type == start)
			{
				al_clear_to_color(al_map_rgb(255, 0, 0));
				
				al_draw_textf(text, BLACK, W/2, H/2-100, ALLEGRO_ALIGN_CENTRE, "Shark Attack");
				al_draw_textf(text, WHITE, W / 2, H / 2+ 50, ALLEGRO_ALIGN_CENTRE, "Press S To Start");
				al_draw_textf(text, WHITE, W / 2, H / 2 + 100, ALLEGRO_ALIGN_CENTRE, "Press Q to quit");
			}

			else if (type == pause)
			{
				al_clear_to_color(al_map_rgb(255, 0, 0));
				al_draw_textf(text, BLACK, W/2 , H/2-100 , ALLEGRO_ALIGN_CENTRE, "Shark Attack");
			 
				al_draw_textf(text, WHITE, W/2 , H/2+50  , ALLEGRO_ALIGN_CENTRE, "Press S to Continue");
				al_draw_textf(text, WHITE, W /2, H/2+100, ALLEGRO_ALIGN_CENTRE, "Press Q to quit");
			}

			else if (type == Killed)
			{
				al_clear_to_color(al_map_rgb(255, 0, 0));
				al_draw_textf(text, BLACK, W / 2, H / 2 - 100, ALLEGRO_ALIGN_CENTRE, "Shark Attack");
				al_draw_textf(text, WHITE, W / 2, H / 2+50, ALLEGRO_ALIGN_CENTRE, "YOUR SUSHI");
				al_draw_textf(text, WHITE, W / 2, H / 2 + 100, ALLEGRO_ALIGN_CENTRE, "Press Q to stop the massacre");
				al_stop_samples();
				if (keys[Q])
				{
					quit = true;
				}
			}

			else if (type == Completion)
			{
				al_clear_to_color(al_map_rgb(255, 0, 0));
				al_draw_textf(text, BLACK, W / 2, H / 2 - 100, ALLEGRO_ALIGN_CENTRE, "Shark Attack");
				al_draw_textf(text, WHITE, W/2 , H/2+50 , ALLEGRO_ALIGN_CENTRE, "Brrp");
				al_draw_textf(text, WHITE, W/2 , H/2+ 100 , ALLEGRO_ALIGN_CENTRE, "Press Q if your full");
				al_stop_samples();
				if (keys[Q])
				{
					quit = true;
				}
			}

			al_flip_display();
		}
	}

	delete shark;
	delete diver;
	delete Fish;
	delete Starfish;
	MapFreeMem();
	al_destroy_font(text);
	al_destroy_display(display);
	al_destroy_timer(timer);
	al_destroy_event_queue(eventQueue);
	al_destroy_sample(music);

	return 0;
}

int collided(int x, int y)
{
	BLKSTR *blockdata;
	blockdata = MapGetBlock(x / mapblockwidth, y / mapblockheight);
	return blockdata->tl || blockdata->tr || blockdata->bl || blockdata->br;
}

void altdis(int &state, int newState)
{
	state = newState;

	switch (state)
	{
	case start: break;
	case play: break;
	case pause: break;
	case Killed: break;
	case Completion: break;
	}
}

bool spriteCollide(Shark *sprite1, Diver *sprite2)
{
	int left1, left2;
	int right1, right2;
	int top1, top2;
	int bottom1, bottom2;

	left1 = sprite1->getX() + sprite1->getCollXOff();
	left2 = sprite2->getX() + sprite2->getCollXOff();
	right1 = left1 + sprite1->getCollWidth();
	right2 = left2 + sprite2->getCollWidth();
	top1 = sprite1->getY() + sprite1->getCollYOff();
	top2 = sprite2->getY() + sprite2->getCollYOff();
	bottom1 = top1 + sprite1->getCollHeight();
	bottom2 = top2 + sprite1->getCollHeight();

	if (bottom1 < top2) return FALSE;
	if (top1 > bottom2) return FALSE;
	if (right1 < left2) return FALSE;
	if (left1 > right2) return FALSE;

	return TRUE;
}	 
bool spriteCollides(Shark *sprite1, fish *sprite2)
{
	int left1, left2;
	int right1, right2;
	int top1, top2;
	int bottom1, bottom2;

	left1 = sprite1->getX() + sprite1->getCollXOff();
	left2 = sprite2->getX() + sprite2->getCollXOff();
	right1 = left1 + sprite1->getCollWidth();
	right2 = left2 + sprite2->getCollWidth();
	top1 = sprite1->getY() + sprite1->getCollYOff();
	top2 = sprite2->getY() + sprite2->getCollYOff();
	bottom1 = top1 + sprite1->getCollHeight();
	bottom2 = top2 + sprite1->getCollHeight();

	if (bottom1 < top2) return FALSE;
	if (top1 > bottom2) return FALSE;
	if (right1 < left2) return FALSE;
	if (left1 > right2) return FALSE;

	return TRUE;
}
bool spriteCollides1(Shark *sprite1, starfish *sprite2)
{
	int left1, left2;
	int right1, right2;
	int top1, top2;
	int bottom1, bottom2;

	left1 = sprite1->getX() + sprite1->getCollXOff();
	left2 = sprite2->getX() + sprite2->getCollXOff();
	right1 = left1 + sprite1->getCollWidth();
	right2 = left2 + sprite2->getCollWidth();
	top1 = sprite1->getY() + sprite1->getCollYOff();
	top2 = sprite2->getY() + sprite2->getCollYOff();
	bottom1 = top1 + sprite1->getCollHeight();
	bottom2 = top2 + sprite1->getCollHeight();

	if (bottom1 < top2) return FALSE;
	if (top1 > bottom2) return FALSE;
	if (right1 < left2) return FALSE;
	if (left1 > right2) return FALSE;

	return TRUE;
}