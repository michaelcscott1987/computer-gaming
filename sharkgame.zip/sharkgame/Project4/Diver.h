/*
Michael Scott
Mr. Jones
Diver.h

*/

#ifndef Diver_H
#define Diver_h

class Diver
{
		private:
			float x, y;
			int width;
			int height;
			ALLEGRO_BITMAP *DiverImage;
			float collWidth;
			float collHeight;
			float collXOffset;
			float collYOffset;
			int dir;
			 

			public:
			Diver(int, int);
			~Diver();

			 
			float getX() {return x;}
			float getY() {return y;}
			int getWidth() {return width;}
			int getHeight() {return height;}
			void drawPlayer (int, int);	
			float getCollWidth() {return collWidth;}
			float getCollHeight() {return collHeight;}
			float getCollXOff() {return collXOffset;}
			float getCollYOff() {return collYOffset;}
};

 
Diver::Diver(int xnumber, int ynumber)
{
	DiverImage = al_load_bitmap("diver.bmp");
	al_convert_mask_to_alpha(DiverImage, al_map_rgb(255,0,255));
	width = al_get_bitmap_width(DiverImage);
	height = al_get_bitmap_height(DiverImage);
	x = xnumber;
	y = ynumber;
	
	int dir = 1;

 
	collWidth  = width * .8;
	collHeight = height * .8;
	collXOffset = (width - collWidth)/2.0;
	collYOffset = (height - collHeight)/2.0;
}

 
Diver::~Diver()
{
	al_destroy_bitmap(DiverImage);
}

void Diver::drawPlayer(int mapx, int mapy)
{	
	al_draw_bitmap(DiverImage, x - mapx, y - mapy, 0);
}

 
#endif

