/*
Michael Scott
Mr. Jones
sharkhandler.h

*/

#ifndef sharkhandler_H
#define SHARKHANDLER_H

 
#define FPS 100

 
#define W 1000
#define H 700
 

 
ALLEGRO_FONT *text;


 
#define BLACK al_map_rgb(0, 0, 0)
#define WHITE al_map_rgb(255, 255, 255)

 
enum KEYS{ up, down, LEFT, RIGHT,P, SPACE, S, Q };
bool keys[] = { false, false, false, false, false, false, false, false };

 
enum type { start, play, pause, Killed, Completion };
int type ;

 
ALLEGRO_SAMPLE *music;

#endif

 