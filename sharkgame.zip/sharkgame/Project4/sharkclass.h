/* 
Michael Scott
sharkClass.h
Mr. Jones
*/

class Shark
{
	private:
			
		float x, y;
			float oldpx, oldpy;
			int width, height;
			int dir;
			int currentframe;
			int max;
			int framec;
		    int framed;
			ALLEGRO_BITMAP *player[1];
			float collWidth;
			float collHeight;
			float collXOffset;
			float collYOffset;
			
			int life;
			int lives;
			int points;
	public:
			Shark();
			~Shark();

			void updatePlayer();
			void setX(int);
			void setY(int);
			float getX() {return x;}
			float getY() {return y;}
			int getWidth() {return width;}
			int getHeight() {return height;}
			int get() {return dir;}
			void drawPlayer (int, int);
			bool loadImage();
			float getCollWidth() {return collWidth;}
			float getCollHeight() {return collHeight;}
			float getCollXOff() {return collXOffset;}
			float getCollYOff() {return collYOffset;}
			int getLife()	{return life;}
			void setLife(int);
            int getPoints()	{ return points; }
			void setPoints(int);
			int getLives()	{return lives;}
			void setLives(int);
};

Shark::Shark()
{
	x = 30.0;
	y = 100.0;
	oldpx = x;
	oldpy = y;
	points = 0;
	framec = 0;
	framed = 4;
	dir = 1;
	currentframe = 0;
	loadImage();
	max = 0;
	life = 1;
	lives = 5;
}  

Shark::~Shark()
{
	for (int ct = 0; ct < 1; ++ct)
	{
		al_destroy_bitmap(player[ct]);
	}
}

bool Shark::loadImage()
{
	player[0] = al_load_bitmap("sharkt.bmp");
	al_convert_mask_to_alpha(player[0], al_map_rgb(255,0,255));
	width = al_get_bitmap_width(player[0]);
	height = al_get_bitmap_height(player[0]);


 

	collWidth = width * .9;
	collHeight = height * .1;
	collXOffset = (width - collWidth)/2;
	collYOffset = (height - collHeight)/2;

	return true;
}

void Shark::updatePlayer()
{
	 

	if (keys[RIGHT])
	{
		dir = 1;
		x += 2;
		if (++framec > framed)
		{
			framec = 0;
			if (++currentframe > max)
				currentframe = 0;
		}
	}

	else if (keys[LEFT])
	{
		dir = 0;
		x -= 2;
		if (x < 0)
			x = 0;
		if (++framec > framed)
		{
			framec = 0;
			if (++currentframe > max)
				currentframe = 0;
		}
	}
	else currentframe = 0;



	if (keys[up])
		{
			y =y- 2;
			if (++framec > framed)
			{
				framec = 0;
				if (++currentframe > max)
					currentframe = 0;
			}
		}	
	else 	if (keys[down])
	{
		y = y + 2;
		if (++framec > framed)
		{
			framec = 0;
			if (++currentframe > max)
				currentframe = 0;
		}
	}






  
	if (!dir)
	{
		if (collided(x, y + height))
			x = oldpx;
	}
	else
	{
		if (collided(x, y + height))
			x = oldpx;
	}
}
void Shark::setLife(int health)
{
	life = health;
}
void Shark::setPoints(int stats)
{
	points = stats;
}


void Shark::setX(int xnumber)
{
	x = xnumber;
}
void Shark::setY(int ynumber)
{
	y = ynumber;
}


void Shark::setLives(int numLives)
{
	lives = numLives;
}





void Shark::drawPlayer(int mapxoffset, int mapyoffset)
{
	if (dir == 1)
		al_draw_bitmap(player[currentframe], (x-mapxoffset), (y-mapyoffset ), 0);
	else if (dir == 0)
		al_draw_bitmap(player[currentframe], (x-mapxoffset), (y-mapyoffset), ALLEGRO_FLIP_HORIZONTAL);
}